declare const InitCommand: any;
export default InitCommand;
