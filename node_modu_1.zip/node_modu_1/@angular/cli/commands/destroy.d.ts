declare const DestroyCommand: any;
export default DestroyCommand;
