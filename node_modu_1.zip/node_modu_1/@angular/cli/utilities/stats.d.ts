export declare function statsToString(json: any, statsConfig: any): any;
export declare function statsWarningsToString(json: any, statsConfig: any): any;
export declare function statsErrorsToString(json: any, statsConfig: any): any;
