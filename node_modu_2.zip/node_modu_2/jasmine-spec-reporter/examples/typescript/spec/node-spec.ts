describe("first suite", () => {
    it("should be ok", () => {
        expect(true).toBe(true);
    });
});
