interface String {
    successful: string;
    failed: string;
    pending: string;
}
